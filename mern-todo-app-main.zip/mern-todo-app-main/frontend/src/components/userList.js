// array of user objects to be loaded initially for testing

const userList = [{
    id:0,
    name : "Aswin Raghuprasad",
    email: "aswinrprasad@gmail.com", 
    mobile: "9605193683",
    password: "fd0abda76d5c674f382ba4043e519470715f0b0e",
    tasks: [
        {
            id_val : 2,
            completed : false,
            desc : "Loaded from const task"
        }
    ],
    logged : false
}]

export default userList