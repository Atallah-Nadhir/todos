import axios from 'axios'

const inst = axios.create()

export default inst