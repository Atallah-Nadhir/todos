import React from 'react'
import './../static/styles/MyFooter.css'
function MyFooter(){
    return(
        <footer id="AwesomeFooter">
            <h2>This is a footer</h2>
        </footer>
    )
}

export default MyFooter