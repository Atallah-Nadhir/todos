import React from 'react'
import './../static/styles/MyHeader.css'
function MyHeader(){
    return (
        <h1 className="navbar">To Do App</h1>
    )
}

export default MyHeader