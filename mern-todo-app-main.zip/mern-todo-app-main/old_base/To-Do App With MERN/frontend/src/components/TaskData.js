let TaskData=[
    {
        id: 1,
        desc: "Go for Shopping",
        completed:false
    },
    {
        id: 2,
        desc: "Check Mails",
        completed:false
    },
    {
        id: 3,
        desc: "Something to do",
        completed:false
    },
    {
        id: 4,
        desc: "Do Programming Tasks",
        completed:false
    },
    {
        id: 5,
        desc: "Something to do 2",
        completed:false
    }
]


export default TaskData